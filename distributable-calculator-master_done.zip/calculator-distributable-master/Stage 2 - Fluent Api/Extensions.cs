﻿using Iqvia.InterviewExercise.Expression.Tests;
using System;
using System.Collections.Generic;
using System.Text;

namespace Iqvia.InterviewExercise.Expression
{
    public static class Extensions
    {
        // Extension methods
        // Method overloading to cover different parameter types
        // to be refactored to reduce the number of methods

        public static AddExpression Plus(this LiteralExpression value, LiteralExpression value2)
        {
            var result = new AddExpression(value, value2);
            return result;
        }

        public static AddExpression Plus(this LiteralExpression value, int value2)
        {
            var result = new AddExpression(value, new LiteralExpression(value2));
            return result;
        }

        public static int Plus(this int i, int value)
        {
            value += i;
            return value;
        }

        public static SubtractExpression Minus(this LiteralExpression value, LiteralExpression value2)
        {
            var result = new SubtractExpression(value,value2);
            return result;
        }

        public static int Minus(this int i, int value)
        {
            value -= i;
            return value;
        }

        public static SubtractExpression Minus(this LiteralExpression value, int value2)
        {
            var result = new SubtractExpression(value, new LiteralExpression(value2));
            return result;
        }

        public static MultiplyExpression Times(this int i, int value)
        {
            var result = new MultiplyExpression(new LiteralExpression(i), new LiteralExpression(value));
            return result;
        }

        public static MultiplyExpression Times(this LiteralExpression value, int value2)
        {
            var result = new MultiplyExpression(value, new LiteralExpression(value2));
            return result;
        }

        public static DivideExpression DividedBy(this int i, int value)
        {
            var result = new DivideExpression(new LiteralExpression(i), new LiteralExpression(value));
            if (value != 0)
            {
                value /= i;
                return result;
            }
            return result;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Iqvia.InterviewExercise.Expression
{
    public class MultiplyExpression : LiteralExpression
    {
        private LiteralExpression arg1;
        private LiteralExpression arg2;

        public MultiplyExpression(LiteralExpression arg1, LiteralExpression arg2) : base(arg1, arg2)
        {
            this.arg1 = arg1;
            this.arg2 = arg2;
        }

        //generates the expression string
        public override string ToString() => $"({arg1}*{arg2})";

        public int Eval()
        {
            //if it is an operation has negative value evaluates operation
            if (arg1.Arg < 0 || arg2.Arg < 0)
            {
                return arg1.Arg * arg2.Arg;
            }
            // else composite evaluates composite value
            else
            {
                var expression = $"({arg1}*{arg2})";
                var result = Evaluate(expression);
                return result;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Iqvia.InterviewExercise.Expression
{
    public class NegateExpression : LiteralExpression
    {
        private LiteralExpression arg1;
        private int result;

        public NegateExpression(LiteralExpression arg1) : base(arg1)
        {
            this.arg1 = arg1;
        }
        //generates the expression string
        public override string ToString() => $"({arg1})";

        public int Eval()
        {
            result = -1 * arg1.Arg;
            return result;
        }
    }
}

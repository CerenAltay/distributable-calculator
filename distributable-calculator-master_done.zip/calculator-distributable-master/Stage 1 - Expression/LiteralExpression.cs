﻿using Iqvia.InterviewExercise.Expression;
using System.Collections.Generic;
using System;
using System.Text;

/// <summary>
/// LiteralExpression class
/// Other expression components inherit from 
/// to be refactored to have an interface
/// </summary>
public class LiteralExpression
{
    private int arg;
    //return value as string
    public int Arg
    {
        get => arg;
        set => arg.ToString();
    }

    public LiteralExpression(int arg)
    {
        this.arg = arg;

    }

    //generates the expression string
    public override string ToString() => $"{Arg}";

    private LiteralExpression Arg1 { get; }
    private LiteralExpression Arg2 { get; }


    //ctor for NegateExpression
    public LiteralExpression(LiteralExpression arg1)
    {
        this.Arg1 = arg1 ?? throw new ArgumentNullException();
    }

    //ctor for other expression components
    public LiteralExpression(LiteralExpression arg1, LiteralExpression arg2)
    {
        this.Arg1 = arg1 ?? throw new ArgumentNullException();
        this.Arg2 = arg2 ?? throw new ArgumentNullException();
    }

    /// <summary>
    /// method that evaluates composite expressions with stacks
    /// </summary>
    /// <param name="expression"></param>
    /// <returns></returns>
    public int Evaluate(string expression)
    {
        char[] tokens = expression.ToCharArray();

        // stack for numbers
        Stack<int> numbers = new Stack<int>();

        // stack for Operators
        Stack<char> operators = new Stack<char>();

        for (int i = 0; i < tokens.Length; i++)
        {
            // skip if current token is a whitespace
            if (tokens[i] == ' ')
            {
                continue;
            }

            // if current token is a number push it to stack for numbers
            if ((tokens[i] >= '0' && tokens[i] <= '9'))
            {
                StringBuilder str = new StringBuilder();

                //if more than one digits in number
                while (i < tokens.Length && tokens[i] >= '0' && tokens[i] <= '9')
                {
                    str.Append(tokens[i++]);
                }
                numbers.Push(int.Parse(str.ToString()));

                // i points to the character next to the digit,
                // correct the offset by skipping one token.
                i--;
            }

            // push to operations if opening brace
            else if (tokens[i] == '(')
            {
                operators.Push(tokens[i]);
            }

            //apply the operation if closing brace 
            else if (tokens[i] == ')')
            {
                while (operators.Peek() != '(')
                {
                    numbers.Push(ApplyOperation(operators.Pop(), numbers.Pop(), numbers.Pop()));
                }
                operators.Pop();
            }

            // check current token is an operator.
            else if (tokens[i] == '+' || tokens[i] == '-' || tokens[i] == '*' || tokens[i] == '/')
            {
                // while top of 'operations' has same or greater precedence to current token
                // apply operator on top of 'operations' to top two elements in numbers stack
                while (operators.Count > 0 && HasPrecedence(tokens[i], operators.Peek()))
                {
                    numbers.Push(ApplyOperation(operators.Pop(), numbers.Pop(), numbers.Pop()));
                }

                // push to operations
                operators.Push(tokens[i]);
            }
        }

        // parsing complete, apply all remaining operations to numbers
        while (operators.Count > 0)
        {
            numbers.Push(ApplyOperation(operators.Pop(), numbers.Pop(), numbers.Pop()));
        }

        // pop top of 'numbers' stack that contains the result 
        return numbers.Pop();
    }

    /// <summary>
    /// helper method to check if op2 has higher precendence than op1
    /// </summary>
    /// <param name="op1"></param>
    /// <param name="op2"></param>
    /// <returns></returns>
    private bool HasPrecedence(char op1, char op2)
    {
        if (op2 == '(' || op2 == ')')
        {
            return false;
        }
        if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-'))
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    /// <summary>
    /// helper method to calculate the operation
    /// </summary>
    /// <param name="op"></param>
    /// <param name="b"></param>
    /// <param name="a"></param>
    /// <returns></returns>
    /// <exception cref="System.NotSupportedException"></exception>
    private int ApplyOperation(char op, int b, int a)
    {
        switch (op)
        {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                if (b == 0)
                {
                    throw new NotSupportedException("Cannot divide by zero");
                }
                return a / b;
        }
        return 0;
    }
}

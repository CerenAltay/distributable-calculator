﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Iqvia.InterviewExercise.Expression
{
    public class BinaryExpressionStrategy : IStrategy

    {
        private LiteralExpression arg1;
        private LiteralExpression arg2;
        private string modulo="%";
        private Func<int, int, int> op = Operate;

        public BinaryExpressionStrategy(LiteralExpression arg1, LiteralExpression arg2, string modulo, Func<int, int, int> op)
        {
            this.arg1 = arg1;
            this.arg2 = arg2;
            this.modulo = modulo;
            this.op = op;
        }

        public static int Operate(int a, int b)
        {
            return a % b;
        }

        public int Eval()
        {
            // Evaluate and return
            var result = op(arg1.Arg, arg2.Arg);
            return result;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Iqvia.InterviewExercise.Expression
{
    public interface IStrategy
    {
        int Eval();
    }
}

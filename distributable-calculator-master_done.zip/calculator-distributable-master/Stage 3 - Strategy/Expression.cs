﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Iqvia.InterviewExercise.Expression
{
    public class Expression : IStrategy
    {
        public int Eval()
        {
            throw new NotImplementedException();
        }
    }
}
